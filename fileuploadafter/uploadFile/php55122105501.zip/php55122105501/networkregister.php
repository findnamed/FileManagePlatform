<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>register demo</title>
    <style>
        h1{
            text-align:center;
            color: white;
        }
        body{
            background-image: url(u=2612004005,906259442&fm=253&fmt=auto&app=120&f=JPEG.webp);
            background-size:cover;
            background-repeat:no-repeat;
        }
        .text{
            color: white;
            font-weight: black;
            text-shadow: 1px 2px black;
        }
        #hobit{
            width: 600px;
            height: 200px;
        }                                                                                                                                                                                                                                                                                                                                                                                                       
        #username,#password,#hobit,#phone,#email{
            text-align:center;
            background-color: rgba(25,52,53,0.1);
            color: white;
            font-size: 15px;
            width: 400px;
        }
        #username:hover{
            background-color: rgba(0,0,255,0.1);
            box-shadow: 2px 2px 2px aqua;
        }

    </style>
</head>
<body>
<form action="1.php" method="post">
    <h1 id="text">注册界面</h1>
    <table align="center" border="5">
        <tr>
            <td><label for="username" class='text'>用户名：</label></td>
            <td><input type="text"  name="uname"  placeholder="请输入您的用户名" ><br></td>
        </tr>

        <tr>
            <td><label for="password" class='text'>密&nbsp;&nbsp;&nbsp;码：</label></td>
            <td><input type="password" name="upassword" id="pw" placeholder="请输入您的密码"><br></td>
        </tr>
        
        <tr>
            <td><label for="password" class='text'>再次输入密码：</label></td>
            <td><input type="password" name="upassword" id="repw" placeholder="请再输入您的密码" required onkeyup="checkpassword()"><span id="tishi"></span><br></td>
        </tr>
        
        <tr>
            <td><label for="sex" class="text">性&nbsp;&nbsp;&nbsp;别：</label></td>
            <td><input type="radio" name="sex">男 <input type="radio" name="sex">女</td>
            
        </tr>

        <tr height="200">
            <td><label for="hobby" class="text">爱&nbsp;&nbsp;&nbsp;好：</label></td>
            <td >
                <input type="checkbox" name="hobby[]" value="王者荣耀">王者荣耀
                <input type="checkbox" name="hobby[]" value="吃饭">吃饭
                <input type="checkbox" name="hobby[]" value="睡觉">睡觉
                <br>
            </td>
        </tr>

        <tr>
            <td><label for="phone" class='text'>手机号：</label></td>
            <td><input type="text" name="uphone"  placeholder="请输入您的电话号码"><br></td>
        </tr>

        <tr>
            <td><label for="email" class='text'>邮&nbsp;&nbsp;&nbsp;箱：</label></td>
            <td><input type="text" name="uemail"  placeholder="请输入您的邮箱"><br></td>
        </tr>

        <tr>
            <td><label for="birthday" class='text'>生&nbsp;&nbsp;&nbsp;日：</label></td>
            <td><input type="date" name="birthday"><br></td>
        </tr>

        <tr>
            <td><label for="address" class='text'>所在地区：</label></td>
            <td>
                <select name="address" id="">
                    <option value="浙江省" name="address[]">浙江省</option>
                    <option value="北京省" name="address[]">北京省</option>
                    <option value="广东省" name="address[]">广东省</option>
                </select>
            </td>

        </tr>

        <tr >
    
            <td><input type="submit" value="注册" id="submit"></td>
            <td><input type="reset" value="重置" id="sub-button"></td>
        </tr>

    </table>
    </form>
<script>
    var start1=document.getElementById("start1");
start1.onclick=function(){
    abc()
}
    function abc(){
        // document.write(alert("注册成功"))
        window.alert("注册成功")
    }
</script>
        <script type="text/javascript">
            function checkpassword(){
                var password = document.getElementById("pw").value;
                var repassword = document.getElementById("repw").value;
                if(password==repassword){
                    document.getElementById("tishi").innerHTML="<br><font color='green'>两次输入密码一致</font>";
                    document.getElementById("submit").disabled=false;
                }else{
                    document.getElementById("tishi").innerHTML="<br><font color='red'>两次输入密码不一致</font>";
                    document.getElementById("submit").disabled=true;  
                }
            }
        </script>



    
</body>
</html>