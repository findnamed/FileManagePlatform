<?php

var_dump($_POST['username']);
echo "<br>";

var_dump($_POST['password']);

echo "<br>";

var_dump($_POST['sex']);

echo "<br>";

var_dump(implode(',',$_POST['hobby']));

echo "<br>";

var_dump($_POST['uphone']);

echo "<br>";

var_dump($_POST['uemail']);

echo "<br>";

var_dump($_POST['birthday']);

echo "<br>";

var_dump($_POST['address']);

